---
title: SelfieBox Event Magic ✨
colorFrom: pink
colorTo: pink
emoji: 🐳
sdk: static
pinned: false
tags:
  - deepsite-v3
---

# Welcome to your new DeepSite project!
This project was created with [DeepSite](https://huggingface.co/deepsite).
